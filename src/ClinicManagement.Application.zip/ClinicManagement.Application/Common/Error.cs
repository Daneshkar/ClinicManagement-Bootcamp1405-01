namespace ClinicManagement.Application.Common;

public record Error(string Code, string Message, ErrorType Type)
{
    public static readonly Error None = new Error(string.Empty, string.Empty, ErrorType.None);
    
    public static Error Validation(string code, string message)
    {
        return new Error(code, message, ErrorType.Validation);
    }
    
    public static Error NotFound(string code, string message)
    {
        return new Error(code, message, ErrorType.NotFound);
    }
    
    public static Error Conflict(string code, string message)
    {
        return new Error(code, message, ErrorType.Conflict);
    }

    public static Error Failure(string code, string message)
    {
        return new Error(code, message, ErrorType.Failure);
    }
    public static Error Unauthorized(string code, string description) => new(code, description, ErrorType.Unauthorized);
    public static Error Forbidden(string code, string description) => new(code, description, ErrorType.Forbidden);

    
}